#!/bin/bash

# ========================================
# DEPLOY AUTOMÁTICO - PERSONAL AGENDA
# ========================================
# Este script faz o deploy do backend usando Docker
# Compatível com qualquer servidor que tenha Docker instalado
# ========================================

echo "🚀 Iniciando deploy do Personal Agenda Backend..."

# Verificar se Docker está instalado
if ! command -v docker &> /dev/null; then
    echo "❌ Docker não está instalado. Instale o Docker primeiro."
    exit 1
fi

# Navegar para o diretório do backend
cd "$(dirname "$0")"

# Parar container antigo se existir
echo "🛑 Parando container antigo..."
docker stop personal-agenda-backend 2>/dev/null || true
docker rm personal-agenda-backend 2>/dev/null || true

# Fazer build da imagem
echo "🔨 Fazendo build da imagem Docker..."
docker build -t personal-agenda-backend:latest .

if [ $? -ne 0 ]; then
    echo "❌ Erro ao fazer build da imagem"
    exit 1
fi

# Iniciar novo container
echo "🚀 Iniciando novo container..."
docker run -d \
  --name personal-agenda-backend \
  --restart unless-stopped \
  -p 3000:3000 \
  --env-file .env \
  personal-agenda-backend:latest

if [ $? -ne 0 ]; then
    echo "❌ Erro ao iniciar container"
    exit 1
fi

# Aguardar container iniciar
echo "⏳ Aguardando container iniciar..."
sleep 5

# Verificar status
echo "📊 Status do container:"
docker ps | grep personal-agenda-backend

# Testar endpoint
echo "🧪 Testando endpoint..."
sleep 3
curl -f http://localhost:3000/health || echo "⚠️ Endpoint de health não respondeu"

echo ""
echo "✅ Deploy concluído!"
echo "📝 Logs: docker logs -f personal-agenda-backend"
echo "🛑 Parar: docker stop personal-agenda-backend"
echo "🔄 Reiniciar: docker restart personal-agenda-backend"
