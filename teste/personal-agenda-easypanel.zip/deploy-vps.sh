#!/bin/bash

# ========================================
# DEPLOY COMPLETO - VPS HOSTINGER
# Personal Agenda Backend
# ========================================
# Execute este script APÓS fazer upload dos arquivos
# Uso: bash deploy-vps.sh
# ========================================

set -e

echo "🚀 Deploy Completo - Personal Agenda Backend"
echo "============================================="
echo ""

# Verificar se estamos no diretório correto
if [ ! -f "package.json" ]; then
    echo "❌ Erro: package.json não encontrado!"
    echo "Execute este script no diretório do projeto: /var/www/personal-agenda-backend"
    exit 1
fi

# Verificar se .env existe
if [ ! -f ".env" ]; then
    echo "⚠️  Arquivo .env não encontrado!"
    echo "Criando .env de exemplo..."
    cp .env.example .env
    echo "⚠️  IMPORTANTE: Edite o arquivo .env com suas credenciais antes de continuar!"
    echo "Execute: nano .env"
    exit 1
fi

# Instalar dependências
echo "📦 Instalando dependências..."
npm install --production

# Parar aplicação antiga se existir
echo "🛑 Parando aplicação antiga..."
pm2 stop personal-agenda 2>/dev/null || true
pm2 delete personal-agenda 2>/dev/null || true

# Iniciar aplicação
echo "🚀 Iniciando aplicação..."
pm2 start src/server.js --name personal-agenda

# Configurar PM2 para iniciar no boot
echo "⚙️  Configurando PM2 para iniciar automaticamente..."
pm2 startup | tail -n 1 | bash || true
pm2 save

# Aguardar aplicação iniciar
echo "⏳ Aguardando aplicação iniciar..."
sleep 5

# Testar aplicação
echo "🧪 Testando aplicação..."
if curl -f http://localhost:3000/health &>/dev/null; then
    echo "✅ Aplicação está rodando!"
else
    echo "⚠️  Aplicação pode não estar respondendo corretamente"
    echo "Verifique os logs: pm2 logs personal-agenda"
fi

# Mostrar status
echo ""
echo "📊 Status da aplicação:"
pm2 status

echo ""
echo "✅ Deploy concluído!"
echo ""
echo "📋 Próximos passos:"
echo "1. Configure o Nginx (veja DEPLOY_VPS_HOSTINGER.md)"
echo "2. Configure o SSL com Certbot"
echo "3. Configure o DNS do domínio"
echo "4. Configure o webhook da Evolution API"
echo ""
echo "🔗 Comandos úteis:"
echo "   pm2 logs personal-agenda    - Ver logs em tempo real"
echo "   pm2 restart personal-agenda - Reiniciar aplicação"
echo "   pm2 monit                   - Monitorar recursos"
echo ""
