#!/bin/bash

# ========================================
# INSTALAÇÃO AUTOMÁTICA - VPS HOSTINGER
# Personal Agenda Backend
# ========================================
# Execute este script na sua VPS para instalar tudo automaticamente
# Uso: bash install-vps.sh
# ========================================

set -e  # Parar em caso de erro

echo "🚀 Instalação Automática - Personal Agenda Backend"
echo "=================================================="
echo ""

# Verificar se está rodando como root
if [ "$EUID" -ne 0 ]; then 
    echo "⚠️  Por favor, execute como root: sudo bash install-vps.sh"
    exit 1
fi

# Atualizar sistema
echo "📦 Atualizando sistema..."
apt update && apt upgrade -y

# Instalar Node.js 18.x
echo "📦 Instalando Node.js 18.x..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    apt install -y nodejs
fi

echo "✅ Node.js $(node --version) instalado"
echo "✅ NPM $(npm --version) instalado"

# Instalar PM2
echo "📦 Instalando PM2..."
npm install -g pm2

# Instalar Git
echo "📦 Instalando Git..."
apt install -y git

# Instalar Nginx
echo "📦 Instalando Nginx..."
apt install -y nginx

# Instalar Certbot para SSL
echo "📦 Instalando Certbot..."
apt install -y certbot python3-certbot-nginx

# Criar diretório do projeto
echo "📁 Criando diretório do projeto..."
mkdir -p /var/www/personal-agenda-backend
cd /var/www/personal-agenda-backend

echo ""
echo "✅ Instalação concluída!"
echo ""
echo "📋 Próximos passos:"
echo "1. Faça upload dos arquivos do backend para: /var/www/personal-agenda-backend/"
echo "2. Crie o arquivo .env com as credenciais"
echo "3. Execute: npm install --production"
echo "4. Execute: pm2 start src/server.js --name personal-agenda"
echo "5. Configure o Nginx (veja DEPLOY_VPS_HOSTINGER.md)"
echo ""
echo "🔗 Comandos úteis:"
echo "   pm2 status          - Ver status da aplicação"
echo "   pm2 logs            - Ver logs"
echo "   pm2 restart all     - Reiniciar aplicação"
echo ""
