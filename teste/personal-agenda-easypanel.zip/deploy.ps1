# ========================================
# DEPLOY AUTOMÁTICO - PERSONAL AGENDA
# ========================================
# Este script faz o deploy do backend usando Docker
# Compatível com Windows PowerShell
# ========================================

Write-Host "🚀 Iniciando deploy do Personal Agenda Backend..." -ForegroundColor Green

# Verificar se Docker está instalado
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Write-Host "❌ Docker não está instalado. Instale o Docker Desktop primeiro." -ForegroundColor Red
    exit 1
}

# Navegar para o diretório do backend
Set-Location $PSScriptRoot

# Parar container antigo se existir
Write-Host "🛑 Parando container antigo..." -ForegroundColor Yellow
docker stop personal-agenda-backend 2>$null
docker rm personal-agenda-backend 2>$null

# Fazer build da imagem
Write-Host "🔨 Fazendo build da imagem Docker..." -ForegroundColor Cyan
docker build -t personal-agenda-backend:latest .

if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Erro ao fazer build da imagem" -ForegroundColor Red
    exit 1
}

# Iniciar novo container
Write-Host "🚀 Iniciando novo container..." -ForegroundColor Green
docker run -d `
  --name personal-agenda-backend `
  --restart unless-stopped `
  -p 3000:3000 `
  --env-file .env `
  personal-agenda-backend:latest

if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Erro ao iniciar container" -ForegroundColor Red
    exit 1
}

# Aguardar container iniciar
Write-Host "⏳ Aguardando container iniciar..." -ForegroundColor Yellow
Start-Sleep -Seconds 5

# Verificar status
Write-Host "📊 Status do container:" -ForegroundColor Cyan
docker ps | Select-String "personal-agenda-backend"

# Testar endpoint
Write-Host "🧪 Testando endpoint..." -ForegroundColor Cyan
Start-Sleep -Seconds 3
try {
    $response = Invoke-WebRequest -Uri "http://localhost:3000/health" -UseBasicParsing -TimeoutSec 5
    Write-Host "✅ Endpoint de health respondeu: $($response.StatusCode)" -ForegroundColor Green
} catch {
    Write-Host "⚠️ Endpoint de health não respondeu" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "✅ Deploy concluído!" -ForegroundColor Green
Write-Host "📝 Ver logs: docker logs -f personal-agenda-backend" -ForegroundColor Cyan
Write-Host "🛑 Parar: docker stop personal-agenda-backend" -ForegroundColor Cyan
Write-Host "🔄 Reiniciar: docker restart personal-agenda-backend" -ForegroundColor Cyan
